package com.example.feature_search.commom.navigation

interface FeatureSearchNavigation {
}