package com.example.navigation.navigators.feature_search

import androidx.fragment.app.Fragment
import com.example.feature_search.commom.navigation.FeatureSearchNavigation

class FeatureSearchNavigationImpl(
    val fragment: Fragment
) : FeatureSearchNavigation {




}